# Terrence Code

Note: topic code still needs to be written.

## ROS Info
### Install
In parentmost directory, the command `colcon build` then `source install/setup.bash` should buld it. Topic code needs to be finalized beforehand

### ROS Dependencies
- rclpy